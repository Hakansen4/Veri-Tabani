--
-- PostgreSQL database dump
--

-- Dumped from database version 12.0
-- Dumped by pg_dump version 12rc1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: BanlanmaTarihiAta(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."BanlanmaTarihiAta"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."BanlanmaTarihi" = CURRENT_TIMESTAMP::TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public."BanlanmaTarihiAta"() OWNER TO postgres;

--
-- Name: KayitTarihiAta(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."KayitTarihiAta"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."KayitTarihi" = CURRENT_TIMESTAMP::TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public."KayitTarihiAta"() OWNER TO postgres;

--
-- Name: UretimTarihiAta(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."UretimTarihiAta"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."uretimTarihi" = CURRENT_TIMESTAMP::TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public."UretimTarihiAta"() OWNER TO postgres;

--
-- Name: UrunBilgiUpdate(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."UrunBilgiUpdate"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW."Fiyati" <> OLD."Fiyati" THEN
        INSERT INTO "UrunDegisikligiGor"("UrunKodu", "EskiFiyat", "YeniFiyat", "DegisiklikTarihi")
        VALUES(OLD."UrunKodu", OLD."Fiyati", NEW."Fiyati", CURRENT_TIMESTAMP::TIMESTAMP);
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public."UrunBilgiUpdate"() OWNER TO postgres;

--
-- Name: UyeKullanıcıAdDegisikligi(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."UyeKullanıcıAdDegisikligi"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW."KullanıcıAd" <> OLD."KullanıcıAd" THEN
        INSERT INTO "UyeDegisikligiGor"("UyeKodu", "EskiKullanıcıAd", "YeniKullanıcıAd", "DegisiklikTarihi")
        VALUES(OLD."UyeKodu", OLD."KullanıcıAd", NEW."KullanıcıAd", CURRENT_TIMESTAMP::TIMESTAMP);
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public."UyeKullanıcıAdDegisikligi"() OWNER TO postgres;

--
-- Name: kullanicigetir(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.kullanicigetir() RETURNS TABLE("kullanıcıad" character varying, sifre character varying, uyekodu integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT
	"KullanıcıAd",
	"Sifre",
	"UyeKodu"
FROM "public"."Uye";
END;
$$;


ALTER FUNCTION public.kullanicigetir() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Admin" (
    "UyeKod" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "BanladigiKisiSayisi" integer DEFAULT 0
);


ALTER TABLE public."Admin" OWNER TO postgres;

--
-- Name: Admin_UyeKod_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Admin_UyeKod_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Admin_UyeKod_seq" OWNER TO postgres;

--
-- Name: Admin_UyeKod_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Admin_UyeKod_seq" OWNED BY public."Admin"."UyeKod";


--
-- Name: Admin_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Admin_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Admin_UyeKodu_seq" OWNER TO postgres;

--
-- Name: Admin_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Admin_UyeKodu_seq" OWNED BY public."Admin"."UyeKodu";


--
-- Name: Alici; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Alici" (
    "UyeKod" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "Alisimiktari" integer DEFAULT 0
);


ALTER TABLE public."Alici" OWNER TO postgres;

--
-- Name: Alici_UyeKod_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Alici_UyeKod_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Alici_UyeKod_seq" OWNER TO postgres;

--
-- Name: Alici_UyeKod_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Alici_UyeKod_seq" OWNED BY public."Alici"."UyeKod";


--
-- Name: Alici_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Alici_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Alici_UyeKodu_seq" OWNER TO postgres;

--
-- Name: Alici_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Alici_UyeKodu_seq" OWNED BY public."Alici"."UyeKodu";


--
-- Name: BanladigiKisiler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BanladigiKisiler" (
    "BanlananKisiNo" integer NOT NULL,
    "BanlananKisiKodu" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "BanlanmaTarihi" date DEFAULT '2019-01-01'::date
);


ALTER TABLE public."BanladigiKisiler" OWNER TO postgres;

--
-- Name: BanladıgıKisiler_BanlananKisiKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BanladıgıKisiler_BanlananKisiKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BanladıgıKisiler_BanlananKisiKodu_seq" OWNER TO postgres;

--
-- Name: BanladıgıKisiler_BanlananKisiKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BanladıgıKisiler_BanlananKisiKodu_seq" OWNED BY public."BanladigiKisiler"."BanlananKisiKodu";


--
-- Name: BanladıgıKisiler_BanlananKisiNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BanladıgıKisiler_BanlananKisiNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BanladıgıKisiler_BanlananKisiNo_seq" OWNER TO postgres;

--
-- Name: BanladıgıKisiler_BanlananKisiNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BanladıgıKisiler_BanlananKisiNo_seq" OWNED BY public."BanladigiKisiler"."BanlananKisiNo";


--
-- Name: BanladıgıKisiler_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BanladıgıKisiler_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BanladıgıKisiler_UyeKodu_seq" OWNER TO postgres;

--
-- Name: BanladıgıKisiler_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BanladıgıKisiler_UyeKodu_seq" OWNED BY public."BanladigiKisiler"."UyeKodu";


--
-- Name: Satici; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Satici" (
    "UyeKod" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "SatisSayisi" integer DEFAULT 0
);


ALTER TABLE public."Satici" OWNER TO postgres;

--
-- Name: SatilmisUrunler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SatilmisUrunler" (
    "SatilmisUrunKodu" integer NOT NULL,
    "UrunKodu" integer NOT NULL
);


ALTER TABLE public."SatilmisUrunler" OWNER TO postgres;

--
-- Name: SatilmisUrunler_SatilmisUrunKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SatilmisUrunler_SatilmisUrunKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SatilmisUrunler_SatilmisUrunKodu_seq" OWNER TO postgres;

--
-- Name: SatilmisUrunler_SatilmisUrunKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SatilmisUrunler_SatilmisUrunKodu_seq" OWNED BY public."SatilmisUrunler"."SatilmisUrunKodu";


--
-- Name: SatilmisUrunler_UrunKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SatilmisUrunler_UrunKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SatilmisUrunler_UrunKodu_seq" OWNER TO postgres;

--
-- Name: SatilmisUrunler_UrunKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SatilmisUrunler_UrunKodu_seq" OWNED BY public."SatilmisUrunler"."UrunKodu";


--
-- Name: SatisAlani; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SatisAlani" (
    "urunNo" integer NOT NULL,
    "UrunKodu" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "Fiyati" money,
    "UrunAdi" character varying(40)
);


ALTER TABLE public."SatisAlani" OWNER TO postgres;

--
-- Name: SatisAlani_UrunKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SatisAlani_UrunKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SatisAlani_UrunKodu_seq" OWNER TO postgres;

--
-- Name: SatisAlani_UrunKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SatisAlani_UrunKodu_seq" OWNED BY public."SatisAlani"."UrunKodu";


--
-- Name: SatisAlani_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SatisAlani_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SatisAlani_UyeKodu_seq" OWNER TO postgres;

--
-- Name: SatisAlani_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SatisAlani_UyeKodu_seq" OWNED BY public."SatisAlani"."UyeKodu";


--
-- Name: SatisAlani_urunNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SatisAlani_urunNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SatisAlani_urunNo_seq" OWNER TO postgres;

--
-- Name: SatisAlani_urunNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SatisAlani_urunNo_seq" OWNED BY public."SatisAlani"."urunNo";


--
-- Name: Satıcı_UyeKod_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Satıcı_UyeKod_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Satıcı_UyeKod_seq" OWNER TO postgres;

--
-- Name: Satıcı_UyeKod_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Satıcı_UyeKod_seq" OWNED BY public."Satici"."UyeKod";


--
-- Name: Satıcı_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Satıcı_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Satıcı_UyeKodu_seq" OWNER TO postgres;

--
-- Name: Satıcı_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Satıcı_UyeKodu_seq" OWNED BY public."Satici"."UyeKodu";


--
-- Name: UrunBilgileri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UrunBilgileri" (
    "UrunKodu" integer NOT NULL,
    "UrunAdi" character varying(40) NOT NULL,
    "uretimTarihi" date DEFAULT '2019-01-01'::date,
    "Fiyati" integer
);


ALTER TABLE public."UrunBilgileri" OWNER TO postgres;

--
-- Name: UrunBilgileri_UrunKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UrunBilgileri_UrunKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UrunBilgileri_UrunKodu_seq" OWNER TO postgres;

--
-- Name: UrunBilgileri_UrunKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UrunBilgileri_UrunKodu_seq" OWNED BY public."UrunBilgileri"."UrunKodu";


--
-- Name: UrunDegisikligiGor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UrunDegisikligiGor" (
    "UrunNo" integer NOT NULL,
    "UrunKodu" integer NOT NULL,
    "EskiFiyat" real NOT NULL,
    "YeniFiyat" real NOT NULL,
    "DegisiklikTarihi" timestamp without time zone NOT NULL
);


ALTER TABLE public."UrunDegisikligiGor" OWNER TO postgres;

--
-- Name: UrunDegisikligiGor_UrunKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UrunDegisikligiGor_UrunKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UrunDegisikligiGor_UrunKodu_seq" OWNER TO postgres;

--
-- Name: UrunDegisikligiGor_UrunKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UrunDegisikligiGor_UrunKodu_seq" OWNED BY public."UrunDegisikligiGor"."UrunKodu";


--
-- Name: UrunDegisikligiGor_UrunNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UrunDegisikligiGor_UrunNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UrunDegisikligiGor_UrunNo_seq" OWNER TO postgres;

--
-- Name: UrunDegisikligiGor_UrunNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UrunDegisikligiGor_UrunNo_seq" OWNED BY public."UrunDegisikligiGor"."UrunNo";


--
-- Name: Uye; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Uye" (
    "UyeKodu" integer NOT NULL,
    "KullanıcıAd" character varying(20) NOT NULL,
    "Sifre" character varying(20) NOT NULL,
    "KayitTarihi" time without time zone
);


ALTER TABLE public."Uye" OWNER TO postgres;

--
-- Name: UyeDegisikligiGor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UyeDegisikligiGor" (
    "UyeDegisikligiNo" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "EskiKullanıcıAd" character varying(20) NOT NULL,
    "YeniKullanıcıAd" character varying(20) NOT NULL,
    "DegisiklikTarihi" timestamp without time zone NOT NULL
);


ALTER TABLE public."UyeDegisikligiGor" OWNER TO postgres;

--
-- Name: UyeDegisikligiGor_UyeDegisikligiNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UyeDegisikligiGor_UyeDegisikligiNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UyeDegisikligiGor_UyeDegisikligiNo_seq" OWNER TO postgres;

--
-- Name: UyeDegisikligiGor_UyeDegisikligiNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UyeDegisikligiGor_UyeDegisikligiNo_seq" OWNED BY public."UyeDegisikligiGor"."UyeDegisikligiNo";


--
-- Name: UyeDegisikligiGor_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UyeDegisikligiGor_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UyeDegisikligiGor_UyeKodu_seq" OWNER TO postgres;

--
-- Name: UyeDegisikligiGor_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UyeDegisikligiGor_UyeKodu_seq" OWNED BY public."UyeDegisikligiGor"."UyeKodu";


--
-- Name: Uye_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Uye_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Uye_UyeKodu_seq" OWNER TO postgres;

--
-- Name: Uye_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Uye_UyeKodu_seq" OWNED BY public."Uye"."UyeKodu";


--
-- Name: YaptigiAlimlar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."YaptigiAlimlar" (
    "AlimKodu" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "UrunKodu" integer NOT NULL
);


ALTER TABLE public."YaptigiAlimlar" OWNER TO postgres;

--
-- Name: YaptigiAlimlar_AlimKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."YaptigiAlimlar_AlimKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."YaptigiAlimlar_AlimKodu_seq" OWNER TO postgres;

--
-- Name: YaptigiAlimlar_AlimKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."YaptigiAlimlar_AlimKodu_seq" OWNED BY public."YaptigiAlimlar"."AlimKodu";


--
-- Name: YaptigiAlimlar_UrunKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."YaptigiAlimlar_UrunKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."YaptigiAlimlar_UrunKodu_seq" OWNER TO postgres;

--
-- Name: YaptigiAlimlar_UrunKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."YaptigiAlimlar_UrunKodu_seq" OWNED BY public."YaptigiAlimlar"."UrunKodu";


--
-- Name: YaptigiAlimlar_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."YaptigiAlimlar_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."YaptigiAlimlar_UyeKodu_seq" OWNER TO postgres;

--
-- Name: YaptigiAlimlar_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."YaptigiAlimlar_UyeKodu_seq" OWNED BY public."YaptigiAlimlar"."UyeKodu";


--
-- Name: YaptigiSatislar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."YaptigiSatislar" (
    "SatisKodu" integer NOT NULL,
    "UyeKodu" integer NOT NULL,
    "UrunKodu" integer NOT NULL
);


ALTER TABLE public."YaptigiSatislar" OWNER TO postgres;

--
-- Name: YaptigiSatislar_SatisKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."YaptigiSatislar_SatisKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."YaptigiSatislar_SatisKodu_seq" OWNER TO postgres;

--
-- Name: YaptigiSatislar_SatisKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."YaptigiSatislar_SatisKodu_seq" OWNED BY public."YaptigiSatislar"."SatisKodu";


--
-- Name: YaptigiSatislar_UrunKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."YaptigiSatislar_UrunKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."YaptigiSatislar_UrunKodu_seq" OWNER TO postgres;

--
-- Name: YaptigiSatislar_UrunKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."YaptigiSatislar_UrunKodu_seq" OWNED BY public."YaptigiSatislar"."UrunKodu";


--
-- Name: YaptigiSatislar_UyeKodu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."YaptigiSatislar_UyeKodu_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."YaptigiSatislar_UyeKodu_seq" OWNER TO postgres;

--
-- Name: YaptigiSatislar_UyeKodu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."YaptigiSatislar_UyeKodu_seq" OWNED BY public."YaptigiSatislar"."UyeKodu";


--
-- Name: Admin UyeKod; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin" ALTER COLUMN "UyeKod" SET DEFAULT nextval('public."Admin_UyeKod_seq"'::regclass);


--
-- Name: Admin UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."Admin_UyeKodu_seq"'::regclass);


--
-- Name: Alici UyeKod; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alici" ALTER COLUMN "UyeKod" SET DEFAULT nextval('public."Alici_UyeKod_seq"'::regclass);


--
-- Name: Alici UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alici" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."Alici_UyeKodu_seq"'::regclass);


--
-- Name: BanladigiKisiler BanlananKisiNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BanladigiKisiler" ALTER COLUMN "BanlananKisiNo" SET DEFAULT nextval('public."BanladıgıKisiler_BanlananKisiNo_seq"'::regclass);


--
-- Name: BanladigiKisiler BanlananKisiKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BanladigiKisiler" ALTER COLUMN "BanlananKisiKodu" SET DEFAULT nextval('public."BanladıgıKisiler_BanlananKisiKodu_seq"'::regclass);


--
-- Name: BanladigiKisiler UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BanladigiKisiler" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."BanladıgıKisiler_UyeKodu_seq"'::regclass);


--
-- Name: Satici UyeKod; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Satici" ALTER COLUMN "UyeKod" SET DEFAULT nextval('public."Satıcı_UyeKod_seq"'::regclass);


--
-- Name: Satici UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Satici" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."Satıcı_UyeKodu_seq"'::regclass);


--
-- Name: SatilmisUrunler SatilmisUrunKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatilmisUrunler" ALTER COLUMN "SatilmisUrunKodu" SET DEFAULT nextval('public."SatilmisUrunler_SatilmisUrunKodu_seq"'::regclass);


--
-- Name: SatilmisUrunler UrunKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatilmisUrunler" ALTER COLUMN "UrunKodu" SET DEFAULT nextval('public."SatilmisUrunler_UrunKodu_seq"'::regclass);


--
-- Name: SatisAlani urunNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatisAlani" ALTER COLUMN "urunNo" SET DEFAULT nextval('public."SatisAlani_urunNo_seq"'::regclass);


--
-- Name: SatisAlani UrunKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatisAlani" ALTER COLUMN "UrunKodu" SET DEFAULT nextval('public."SatisAlani_UrunKodu_seq"'::regclass);


--
-- Name: SatisAlani UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatisAlani" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."SatisAlani_UyeKodu_seq"'::regclass);


--
-- Name: UrunBilgileri UrunKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UrunBilgileri" ALTER COLUMN "UrunKodu" SET DEFAULT nextval('public."UrunBilgileri_UrunKodu_seq"'::regclass);


--
-- Name: UrunDegisikligiGor UrunNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UrunDegisikligiGor" ALTER COLUMN "UrunNo" SET DEFAULT nextval('public."UrunDegisikligiGor_UrunNo_seq"'::regclass);


--
-- Name: UrunDegisikligiGor UrunKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UrunDegisikligiGor" ALTER COLUMN "UrunKodu" SET DEFAULT nextval('public."UrunDegisikligiGor_UrunKodu_seq"'::regclass);


--
-- Name: Uye UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Uye" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."Uye_UyeKodu_seq"'::regclass);


--
-- Name: UyeDegisikligiGor UyeDegisikligiNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UyeDegisikligiGor" ALTER COLUMN "UyeDegisikligiNo" SET DEFAULT nextval('public."UyeDegisikligiGor_UyeDegisikligiNo_seq"'::regclass);


--
-- Name: UyeDegisikligiGor UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UyeDegisikligiGor" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."UyeDegisikligiGor_UyeKodu_seq"'::regclass);


--
-- Name: YaptigiAlimlar AlimKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiAlimlar" ALTER COLUMN "AlimKodu" SET DEFAULT nextval('public."YaptigiAlimlar_AlimKodu_seq"'::regclass);


--
-- Name: YaptigiAlimlar UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiAlimlar" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."YaptigiAlimlar_UyeKodu_seq"'::regclass);


--
-- Name: YaptigiAlimlar UrunKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiAlimlar" ALTER COLUMN "UrunKodu" SET DEFAULT nextval('public."YaptigiAlimlar_UrunKodu_seq"'::regclass);


--
-- Name: YaptigiSatislar SatisKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiSatislar" ALTER COLUMN "SatisKodu" SET DEFAULT nextval('public."YaptigiSatislar_SatisKodu_seq"'::regclass);


--
-- Name: YaptigiSatislar UyeKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiSatislar" ALTER COLUMN "UyeKodu" SET DEFAULT nextval('public."YaptigiSatislar_UyeKodu_seq"'::regclass);


--
-- Name: YaptigiSatislar UrunKodu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiSatislar" ALTER COLUMN "UrunKodu" SET DEFAULT nextval('public."YaptigiSatislar_UrunKodu_seq"'::regclass);


--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: Alici; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: BanladigiKisiler; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: Satici; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Satici" VALUES (1, 3, 0);


--
-- Data for Name: SatilmisUrunler; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: SatisAlani; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: UrunBilgileri; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."UrunBilgileri" VALUES (1, 'ty', '2019-01-01', NULL);
INSERT INTO public."UrunBilgileri" VALUES (2, 'Telefon', '2019-12-18', NULL);
INSERT INTO public."UrunBilgileri" VALUES (3, 'Abc', '2019-12-18', 12);


--
-- Data for Name: UrunDegisikligiGor; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."UrunDegisikligiGor" VALUES (1, 3, 4124, 12, '2019-12-18 18:27:36.632731');


--
-- Data for Name: Uye; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Uye" VALUES (2, 'dgb', 'rgn', NULL);
INSERT INTO public."Uye" VALUES (3, 'dgbfgj', 'rgnthr', NULL);
INSERT INTO public."Uye" VALUES (4, 'dgbfgjfbvgbgb', 'rgnthrgg', NULL);
INSERT INTO public."Uye" VALUES (5, 'form1', 'sif', NULL);
INSERT INTO public."Uye" VALUES (6, 'form1dsfgv', 'sif', NULL);
INSERT INTO public."Uye" VALUES (7, 'deneme', 'asd', '11:05:27.298226');
INSERT INTO public."Uye" VALUES (1, 'Ali', 'dasd', NULL);


--
-- Data for Name: UyeDegisikligiGor; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."UyeDegisikligiGor" VALUES (1, 1, 'eaa', 'Ali', '2019-12-18 18:58:57.045259');


--
-- Data for Name: YaptigiAlimlar; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: YaptigiSatislar; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: Admin_UyeKod_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Admin_UyeKod_seq"', 1, false);


--
-- Name: Admin_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Admin_UyeKodu_seq"', 1, false);


--
-- Name: Alici_UyeKod_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Alici_UyeKod_seq"', 1, false);


--
-- Name: Alici_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Alici_UyeKodu_seq"', 1, false);


--
-- Name: BanladıgıKisiler_BanlananKisiKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BanladıgıKisiler_BanlananKisiKodu_seq"', 1, false);


--
-- Name: BanladıgıKisiler_BanlananKisiNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BanladıgıKisiler_BanlananKisiNo_seq"', 1, false);


--
-- Name: BanladıgıKisiler_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BanladıgıKisiler_UyeKodu_seq"', 1, false);


--
-- Name: SatilmisUrunler_SatilmisUrunKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SatilmisUrunler_SatilmisUrunKodu_seq"', 1, false);


--
-- Name: SatilmisUrunler_UrunKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SatilmisUrunler_UrunKodu_seq"', 1, false);


--
-- Name: SatisAlani_UrunKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SatisAlani_UrunKodu_seq"', 1, false);


--
-- Name: SatisAlani_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SatisAlani_UyeKodu_seq"', 1, false);


--
-- Name: SatisAlani_urunNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SatisAlani_urunNo_seq"', 1, false);


--
-- Name: Satıcı_UyeKod_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Satıcı_UyeKod_seq"', 1, true);


--
-- Name: Satıcı_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Satıcı_UyeKodu_seq"', 1, false);


--
-- Name: UrunBilgileri_UrunKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UrunBilgileri_UrunKodu_seq"', 3, true);


--
-- Name: UrunDegisikligiGor_UrunKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UrunDegisikligiGor_UrunKodu_seq"', 1, false);


--
-- Name: UrunDegisikligiGor_UrunNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UrunDegisikligiGor_UrunNo_seq"', 1, true);


--
-- Name: UyeDegisikligiGor_UyeDegisikligiNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UyeDegisikligiGor_UyeDegisikligiNo_seq"', 1, true);


--
-- Name: UyeDegisikligiGor_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UyeDegisikligiGor_UyeKodu_seq"', 1, false);


--
-- Name: Uye_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Uye_UyeKodu_seq"', 7, true);


--
-- Name: YaptigiAlimlar_AlimKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."YaptigiAlimlar_AlimKodu_seq"', 1, false);


--
-- Name: YaptigiAlimlar_UrunKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."YaptigiAlimlar_UrunKodu_seq"', 1, false);


--
-- Name: YaptigiAlimlar_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."YaptigiAlimlar_UyeKodu_seq"', 1, false);


--
-- Name: YaptigiSatislar_SatisKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."YaptigiSatislar_SatisKodu_seq"', 2, true);


--
-- Name: YaptigiSatislar_UrunKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."YaptigiSatislar_UrunKodu_seq"', 1, false);


--
-- Name: YaptigiSatislar_UyeKodu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."YaptigiSatislar_UyeKodu_seq"', 1, false);


--
-- Name: Admin AdminPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "AdminPK" PRIMARY KEY ("UyeKod");


--
-- Name: Admin AdminUnique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "AdminUnique" UNIQUE ("UyeKodu");


--
-- Name: Alici AliciPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alici"
    ADD CONSTRAINT "AliciPK" PRIMARY KEY ("UyeKod");


--
-- Name: Alici AliciUnique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alici"
    ADD CONSTRAINT "AliciUnique" UNIQUE ("UyeKodu");


--
-- Name: YaptigiAlimlar AlimlarPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiAlimlar"
    ADD CONSTRAINT "AlimlarPK" PRIMARY KEY ("AlimKodu");


--
-- Name: BanladigiKisiler B-KPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BanladigiKisiler"
    ADD CONSTRAINT "B-KPK" PRIMARY KEY ("BanlananKisiNo");


--
-- Name: SatisAlani S_APK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatisAlani"
    ADD CONSTRAINT "S_APK" PRIMARY KEY ("urunNo");


--
-- Name: SatilmisUrunler S_UrunlerPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatilmisUrunler"
    ADD CONSTRAINT "S_UrunlerPK" PRIMARY KEY ("SatilmisUrunKodu");


--
-- Name: Satici SaticiUnique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Satici"
    ADD CONSTRAINT "SaticiUnique" UNIQUE ("UyeKodu");


--
-- Name: YaptigiSatislar SatisPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiSatislar"
    ADD CONSTRAINT "SatisPK" PRIMARY KEY ("SatisKodu");


--
-- Name: Satici SatıcıPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Satici"
    ADD CONSTRAINT "SatıcıPK" PRIMARY KEY ("UyeKod");


--
-- Name: UrunDegisikligiGor UrunDPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UrunDegisikligiGor"
    ADD CONSTRAINT "UrunDPK" PRIMARY KEY ("UrunNo");


--
-- Name: UrunBilgileri UrunPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UrunBilgileri"
    ADD CONSTRAINT "UrunPK" PRIMARY KEY ("UrunKodu");


--
-- Name: Uye UyePK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Uye"
    ADD CONSTRAINT "UyePK" PRIMARY KEY ("UyeKodu");


--
-- Name: UyeDegisikligiGor Uye_DPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UyeDegisikligiGor"
    ADD CONSTRAINT "Uye_DPK" PRIMARY KEY ("UyeDegisikligiNo");


--
-- Name: BanladigiKisiler Banladığında; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "Banladığında" BEFORE INSERT ON public."BanladigiKisiler" FOR EACH ROW EXECUTE FUNCTION public."BanlanmaTarihiAta"();


--
-- Name: UrunBilgileri UrunOldugunda; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "UrunOldugunda" BEFORE INSERT ON public."UrunBilgileri" FOR EACH ROW EXECUTE FUNCTION public."UretimTarihiAta"();


--
-- Name: Uye UyeKullaniciAdDegistiginde; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "UyeKullaniciAdDegistiginde" BEFORE UPDATE ON public."Uye" FOR EACH ROW EXECUTE FUNCTION public."UyeKullanıcıAdDegisikligi"();


--
-- Name: UrunBilgileri urunFiyatDegistiginde; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "urunFiyatDegistiginde" BEFORE UPDATE ON public."UrunBilgileri" FOR EACH ROW EXECUTE FUNCTION public."UrunBilgiUpdate"();


--
-- Name: Uye uyeOlundugunda; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "uyeOlundugunda" BEFORE INSERT ON public."Uye" FOR EACH ROW EXECUTE FUNCTION public."KayitTarihiAta"();


--
-- Name: Admin AdminFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "AdminFK" FOREIGN KEY ("UyeKodu") REFERENCES public."Uye"("UyeKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Alici AliciFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Alici"
    ADD CONSTRAINT "AliciFK" FOREIGN KEY ("UyeKodu") REFERENCES public."Uye"("UyeKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: YaptigiAlimlar AlimFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiAlimlar"
    ADD CONSTRAINT "AlimFK" FOREIGN KEY ("UyeKodu") REFERENCES public."Alici"("UyeKod") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: YaptigiAlimlar AlimFK2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiAlimlar"
    ADD CONSTRAINT "AlimFK2" FOREIGN KEY ("UrunKodu") REFERENCES public."SatilmisUrunler"("SatilmisUrunKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BanladigiKisiler B_KFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BanladigiKisiler"
    ADD CONSTRAINT "B_KFK" FOREIGN KEY ("UyeKodu") REFERENCES public."Admin"("UyeKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BanladigiKisiler B_KFK2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BanladigiKisiler"
    ADD CONSTRAINT "B_KFK2" FOREIGN KEY ("UyeKodu") REFERENCES public."Uye"("UyeKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SatisAlani S_AFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatisAlani"
    ADD CONSTRAINT "S_AFK" FOREIGN KEY ("UyeKodu") REFERENCES public."UrunBilgileri"("UrunKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SatisAlani S_AFK2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatisAlani"
    ADD CONSTRAINT "S_AFK2" FOREIGN KEY ("UyeKodu") REFERENCES public."Uye"("UyeKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SatilmisUrunler S_UrunFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SatilmisUrunler"
    ADD CONSTRAINT "S_UrunFK" FOREIGN KEY ("UrunKodu") REFERENCES public."UrunBilgileri"("UrunKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: YaptigiSatislar Satis2FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiSatislar"
    ADD CONSTRAINT "Satis2FK" FOREIGN KEY ("UrunKodu") REFERENCES public."SatilmisUrunler"("SatilmisUrunKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: YaptigiSatislar SatisFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."YaptigiSatislar"
    ADD CONSTRAINT "SatisFK" FOREIGN KEY ("UyeKodu") REFERENCES public."Satici"("UyeKod") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Satici SatıcıFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Satici"
    ADD CONSTRAINT "SatıcıFK" FOREIGN KEY ("UyeKodu") REFERENCES public."Uye"("UyeKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UrunDegisikligiGor UrunDFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UrunDegisikligiGor"
    ADD CONSTRAINT "UrunDFK" FOREIGN KEY ("UrunKodu") REFERENCES public."UrunBilgileri"("UrunKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UyeDegisikligiGor Uye_DFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UyeDegisikligiGor"
    ADD CONSTRAINT "Uye_DFK" FOREIGN KEY ("UyeKodu") REFERENCES public."Uye"("UyeKodu") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

